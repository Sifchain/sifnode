export CONTAINER_NAME=integration_sifnode1_1
export BASEDIR=/sifnode/test/integration/../..
export YARN_CACHE_DIR=/home/vagrant/.cache/yarn/v6
export ETHEREUM_CONTRACT_ADDRESS="0x82D50AD3C1091866E258Fd0f1a7cC9674609D254"
# BRIDGE_REGISTRY_ADDRESS and ETHEREUM_CONTRACT_ADDRESS are synonyms
export BRIDGE_REGISTRY_ADDRESS="0x82D50AD3C1091866E258Fd0f1a7cC9674609D254"
export BRIDGE_BANK_ADDRESS="0xf204a4Ef082f5c04bB89F7D5E6568B796096735a"
export NETDEF=/sifnode/test/integration/../../deploy/networks/network-definition.yml
export MONIKER="bitter-grass"
export MONIKER="bitter-grass"
export OWNER_PASSWORD=mnU3G9q4Xh6RotD2wVFbeNEkPYOKxpHa
export OWNER_ADDR=sif1h3sm30j3chnl5d70pswcjyt6zugc9gez3v3pya
export USER1ADDR=sif1q8kj4m5fjry79r9fd9p5u2ckdxx6pxn6055jg5
